package com.petclinic.practice;

public class GreetingService {
    public String sayHi() {
        return "Hello John";
    }
}
