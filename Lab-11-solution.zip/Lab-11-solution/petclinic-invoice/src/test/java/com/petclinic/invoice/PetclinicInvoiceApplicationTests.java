package com.petclinic.invoice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetclinicInvoiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
