package com.petclinic.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetclinicAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
