# Setting up profiles
By default, the profile "inmemory" is activated

If you wish to store users in database, use the below active profile instead:
spring.profiles.active=database